def show_homepage():
    print("\n === DonateMe Homepage === ")
    print("------------------------------------------")
    print("| 1. Login | 2. Register |")
    print("------------------------------------------")
    print("| 3. Donate | 4. Show Donations |")
    print("------------------------------------------")
    print("| 5. Exit |")
    print("------------------------------------------")
